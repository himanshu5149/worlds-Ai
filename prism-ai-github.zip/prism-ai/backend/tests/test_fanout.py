"""Fan-out orchestrator: eligibility, parallel calls, timeouts, judging,
hidden identity, error typing."""

from app.embeddings.embedder import LocalHashEmbedder
from app.orchestrator.fanout import FanoutOrchestrator
from app.orchestrator.normalize import normalize_query
from app.providers.base import ErrorType
from app.providers.registry import ModelRegistry

from .conftest import add_models
from .fakes import FakeAdapter

Q = "What is the capital of France?"

GOOD_A = {
    "fake/good": (
        "The capital of France is Paris. Paris has been the capital since 508 AD and "
        "is located on the river Seine in the northern part of the country. The city "
        "is also the seat of the French government and home to the National Assembly."
    ),
    "fake/second": (
        "The capital of France is Paris. It is famous for landmarks such as the Eiffel "
        "Tower and the Louvre museum."
    ),
}


async def _orchestrator(db, settings, adapters: dict[str, FakeAdapter]) -> tuple[FanoutOrchestrator, ModelRegistry]:
    registry = ModelRegistry(db, settings)
    for provider, adapter in adapters.items():
        registry._adapters[provider] = adapter
    embedder = LocalHashEmbedder(settings.embedding_dim)
    orchestrator = FanoutOrchestrator(registry, embedder, settings)
    return orchestrator, registry


async def test_fanout_selects_best_and_hides_identity(db, settings):
    adapters = {
        "fake": FakeAdapter(
            answers={
                "good": GOOD_A["fake/good"],
                "second": GOOD_A["fake/second"],
                "bad": "Puppies are cute and fluffy animals that people keep as pets.",
            },
            latency=0.03,
        )
    }
    await add_models(db, [
        {"id": "fake/good", "provider": "fake", "weight": 1.0, "status": "ACTIVE"},
        {"id": "fake/second", "provider": "fake", "weight": 0.9, "status": "ACTIVE"},
        {"id": "fake/bad", "provider": "fake", "weight": 0.8, "status": "ACTIVE"},
        {"id": "fake/extra", "provider": "fake", "weight": 0.1, "status": "ACTIVE"},
    ])
    orchestrator, _ = await _orchestrator(db, settings, adapters)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    assert outcome.status == "completed"
    assert "Paris" in (outcome.answer or "")
    # Max 4 models fanned out even though more are ACTIVE.
    assert len(adapters["fake"].calls) <= 4
    # The winner must be the most relevant candidate.
    assert outcome.candidates[0].candidate.model_id == "fake/good"
    # Hidden identity: no model/provider names in the final answer.
    for banned in ("fake", "gpt", "claude", "provider"):
        assert banned not in (outcome.answer or "").lower()


async def test_self_identifying_answer_is_sanitized(db, settings):
    adapters = {
        "fake": FakeAdapter(
            answers={
                "model": (
                    "I am ChatGPT, an AI assistant created by OpenAI. The capital of "
                    "France is Paris, located on the Seine river."
                )
            },
            latency=0.02,
        )
    }
    await add_models(db, [{"id": "fake/model", "provider": "fake", "status": "ACTIVE"}])
    orchestrator, _ = await _orchestrator(db, settings, adapters)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    assert outcome.status == "completed"
    assert "ChatGPT" not in outcome.answer
    assert "OpenAI" not in outcome.answer
    assert "Paris" in outcome.answer


async def test_slow_model_hits_hard_timeout(db, settings):
    adapters = {"fake": FakeAdapter(answers={}, latency=5.0)}  # >> hard timeout 1.2s
    await add_models(db, [{"id": "fake/slow", "provider": "fake", "status": "ACTIVE"}])
    orchestrator, _ = await _orchestrator(db, settings, adapters)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    # No other tier, no cache, queue disabled -> clear failure, no fabricated answer.
    assert outcome.status == "failed"
    assert outcome.answer is None
    assert any(f["error_type"] == ErrorType.TIMEOUT.value for f in outcome.failures)
    assert outcome.error == "no_model_available"


async def test_rate_limited_model_is_typed_and_excluded(db, settings):
    adapters = {"fake": FakeAdapter(answers={}, error=ErrorType.RATE_LIMITED)}
    await add_models(db, [{"id": "fake/rl", "provider": "fake", "status": "ACTIVE"}])
    orchestrator, _ = await _orchestrator(db, settings, adapters)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    assert outcome.status == "failed"
    assert any(f["error_type"] == "RATE_LIMITED" for f in outcome.failures)


async def test_error_leak_response_rejected_by_safety_gate(db, settings):
    adapters = {
        "fake": FakeAdapter(
            answers={"model": "Error 429: rate limit exceeded. Please retry later."},
            latency=0.02,
        )
    }
    await add_models(db, [{"id": "fake/model", "provider": "fake", "status": "ACTIVE"}])
    orchestrator, _ = await _orchestrator(db, settings, adapters)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    # The only candidate was rejected -> fallback chain -> failure.
    assert outcome.status == "failed"
    assert outcome.answer is None


async def test_normalize_detects_time_sensitivity_and_intent():
    nq = normalize_query("What is the current price of Bitcoin in USD today?")
    assert nq.time_sensitive is True
    assert nq.intent == "factual"
    nq2 = normalize_query("Compare GPT-4 vs Claude for coding")
    assert nq2.intent == "compare"
    assert not nq2.time_sensitive


async def test_partial_failure_still_returns_answer(db, settings):
    from app.providers.base import ProviderError

    adapters = {
        "fake": FakeAdapter(
            answers={"ok": GOOD_A["fake/good"], "boom": "x"},
            latency=0.02,
            error=None,
        )
    }
    await add_models(db, [
        {"id": "fake/ok", "provider": "fake", "status": "ACTIVE"},
        {"id": "fake/boom", "provider": "fake", "status": "ACTIVE"},
    ])
    # Make only 'boom' fail.
    original = adapters["fake"].generate

    async def generate_patch(*, model, **kwargs):
        if model == "boom":
            raise ProviderError(ErrorType.PROVIDER_DOWN, "boom", provider="fake")
        return await original(model=model, **kwargs)

    adapters["fake"].generate = generate_patch
    orchestrator, _ = await _orchestrator(db, settings, adapters)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    assert outcome.status == "completed"
    assert "Paris" in outcome.answer
    assert any(f["error_type"] == "PROVIDER_DOWN" for f in outcome.failures)
