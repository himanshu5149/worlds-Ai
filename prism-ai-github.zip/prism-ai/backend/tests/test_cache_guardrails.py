"""Semantic cache guardrails: every rule must pass before a hit is served."""
from datetime import UTC, datetime, timedelta

from app.cache.guardrails import cosine, guardrails_pass, jaccard

NOW = datetime.now(UTC)


def _base_kwargs(**overrides):
    kwargs = dict(
        similarity=0.95,
        intent_q="factual",
        intent_e="factual",
        lang_q="en",
        lang_e="en",
        entities_q={"proper_nouns": ["Paris"]},
        entities_e={"proper_nouns": ["Paris"]},
        time_sensitive_q=False,
        entry_created_at=NOW - timedelta(hours=1),
        now=NOW,
        confidence=0.9,
        expires_at=NOW + timedelta(hours=5),
        threshold=0.92,
        entity_jaccard_min=0.6,
        confidence_threshold=0.85,
        time_sensitive_max_age_s=900,
    )
    kwargs.update(overrides)
    return kwargs


def test_passes_when_all_guardrails_ok():
    ok, failed = guardrails_pass(**_base_kwargs())
    assert ok and not failed


def test_fails_below_similarity_threshold():
    ok, failed = guardrails_pass(**_base_kwargs(similarity=0.80))
    assert not ok and any("similarity" in f for f in failed)


def test_fails_on_intent_mismatch():
    ok, failed = guardrails_pass(**_base_kwargs(intent_q="howto"))
    assert not ok and any("intent" in f for f in failed)


def test_fails_on_language_mismatch():
    ok, failed = guardrails_pass(**_base_kwargs(lang_q="fr"))
    assert not ok and any("language" in f for f in failed)


def test_fails_on_entity_mismatch():
    ok, failed = guardrails_pass(**_base_kwargs(entities_q={"proper_nouns": ["Tokyo"]}))
    assert not ok and any("entity" in f for f in failed)


def test_fails_on_key_entity_mismatch():
    # Same topic, different date/number -> must not serve.
    ok, failed = guardrails_pass(
        **_base_kwargs(
            entities_q={"dates": ["2024-01-15"]},
            entities_e={"dates": ["2023-01-15"]},
        )
    )
    assert not ok and any("key_entities" in f for f in failed)


def test_fails_stale_time_sensitive():
    ok, failed = guardrails_pass(
        **_base_kwargs(
            time_sensitive_q=True,
            entry_created_at=NOW - timedelta(minutes=30),  # older than 15 min window
        )
    )
    assert not ok and any("time_sensitive" in f for f in failed)


def test_time_sensitive_passes_when_fresh():
    ok, _failed = guardrails_pass(
        **_base_kwargs(time_sensitive_q=True, entry_created_at=NOW - timedelta(minutes=2))
    )
    assert ok


def test_fails_below_confidence():
    ok, failed = guardrails_pass(**_base_kwargs(confidence=0.7))
    assert not ok and any("confidence" in f for f in failed)


def test_fails_when_expired():
    ok, failed = guardrails_pass(**_base_kwargs(expires_at=NOW - timedelta(minutes=1)))
    assert not ok and any("expired" in f for f in failed)


def test_cosine_and_jaccard_math():
    assert abs(cosine([1, 0], [1, 0]) - 1.0) < 1e-9
    assert abs(cosine([1, 0], [0, 1])) < 1e-9
    assert cosine([], [1]) == 0.0
    assert jaccard({"a", "b"}, {"b", "c"}) == 1 / 3
    assert jaccard(set(), set()) == 1.0
    assert jaccard({"a"}, set()) == 0.0
