"""Model registry: seeding, eligibility, credentials, stub gating."""

from app.providers.base import ModelStatus
from app.providers.registry import ADAPTER_CLASSES, DEFAULT_MODEL_CATALOG, ModelRegistry

from .conftest import add_models
from .fakes import FakeAdapter


async def test_seed_catalog_populates_once(db, settings):
    registry = ModelRegistry(db, settings)
    await registry.seed_defaults()
    models = await registry.list_models()
    assert {m["id"] for m in DEFAULT_MODEL_CATALOG} <= {m.id for m in models}
    # idempotent
    await registry.seed_defaults()
    assert len(await registry.list_models()) == len(models)


def test_all_required_providers_have_adapters():
    assert {"openai", "anthropic", "gemini", "mistral", "cohere", "deepseek", "xai", "ollama"} == set(ADAPTER_CLASSES)


def test_official_adapters_not_marked_unverified():
    for name, cls in ADAPTER_CLASSES.items():
        assert cls.requires_verification is False, f"{name} must be verified"
        assert cls.default_base_url, f"{name} needs a base url"
        assert cls.verified_docs, f"{name} needs docs link"


async def test_eligibility_excludes_bad_statuses(db, settings):
    registry = ModelRegistry(db, settings)
    registry._adapters["fake"] = FakeAdapter()
    await add_models(db, [
        {"id": "fake/active", "provider": "fake", "status": "ACTIVE"},
        {"id": "fake/degraded", "provider": "fake", "status": "DEGRADED"},
        {"id": "fake/down", "provider": "fake", "status": "DOWN"},
        {"id": "fake/auth", "provider": "fake", "status": "AUTH_REQUIRED"},
        {"id": "fake/paid", "provider": "fake", "status": "PAID_REQUIRED"},
        {"id": "fake/cooling", "provider": "fake", "status": "COOLING"},
    ])
    eligible = await registry.eligible()
    ids = {e.model_id for e in eligible}
    assert "fake/active" in ids
    assert "fake/degraded" in ids
    assert not ids & {"fake/down", "fake/auth", "fake/paid", "fake/cooling"}
    # DEGRADED ranks below ACTIVE at equal weight.
    weights = {e.model_id: e.selection_score for e in eligible}
    assert weights["fake/active"] > weights["fake/degraded"]


async def test_models_without_credentials_are_excluded(db, settings):
    registry = ModelRegistry(db, settings)
    await registry.seed_defaults()
    # No keys configured anywhere -> cloud models ineligible.
    eligible = await registry.eligible()
    cloud_ids = [e.model_id for e in eligible if e.tier != "local"]
    assert cloud_ids == []
    # Local tier (no credentials needed) remains eligible when healthy.
    async with db() as session:
        from app.db.models import Model

        for model in (await session.scalars(select(Model).where(Model.tier == "local"))).all():
            model.status = ModelStatus.ACTIVE.value
        await session.commit()
    eligible = await registry.eligible()
    assert all(e.tier == "local" for e in eligible)


async def test_stub_connectors_gated(db, settings):
    registry = ModelRegistry(db, settings)
    await add_models(db, [{"id": "stub/x", "provider": "unknown-provider", "tier": "stub", "status": "ACTIVE"}])
    eligible = await registry.eligible()
    assert [e.model_id for e in eligible] == []
    # With mock providers explicitly enabled (dev only) the stub becomes eligible.
    settings.allow_mock_providers = True
    eligible = await registry.eligible()
    assert "stub/x" in {e.model_id for e in eligible}
    settings.allow_mock_providers = False


async def test_credential_resolution_prefers_env_key(db, settings):
    registry = ModelRegistry(db, settings)
    settings.openai_api_key = "sk-test-env"
    key = await registry.credential_for("openai")
    assert key == "sk-test-env"
    adapter = await registry.get_adapter("openai")
    assert adapter.has_credentials is True
    settings.openai_api_key = None


async def test_unknown_provider_gets_stub(db, settings):
    registry = ModelRegistry(db, settings)
    adapter = await registry.get_adapter("some-future-provider")
    assert adapter.requires_verification is True


from sqlalchemy import select
