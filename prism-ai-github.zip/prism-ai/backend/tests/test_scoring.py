"""Heuristic judge: dimension sanity + weight invariants."""
from app.judge.scoring import DIMENSION_WEIGHTS, HeuristicJudge, split_sentences
from app.orchestrator.normalize import normalize_query


def _judge(settings):
    return HeuristicJudge(settings)


def test_weights_sum_to_one():
    assert abs(sum(DIMENSION_WEIGHTS.values()) - 1.0) < 1e-9


def test_relevance_prefers_on_topic_answer(settings):
    judge = _judge(settings)
    query = normalize_query("What is the capital of France?")
    on_topic = (
        "The capital of France is Paris. Paris is located on the river Seine in "
        "northern France and is the country's largest city."
    )
    off_topic = (
        "Penguins are flightless birds that live in the Southern Hemisphere and "
        "feed mostly on fish and krill."
    )
    good = judge.score(query, on_topic, 500)
    bad = judge.score(query, off_topic, 500)
    assert good.relevance > bad.relevance + 0.4
    assert good.total > bad.total


def test_factuality_penalizes_heavy_hedging(settings):
    judge = _judge(settings)
    query = normalize_query("When was the Eiffel Tower built?")
    hedged = (
        "I think the Eiffel Tower was probably built around 1889, maybe 1887. "
        "I'm not sure though. It could be around then. I guess that's right. "
        "Perhaps you should check."
    )
    clean = "The Eiffel Tower was completed in 1889 for the 1889 World's Fair in Paris."
    assert judge.score(query, clean, 500).factuality > judge.score(query, hedged, 500).factuality


def test_factuality_penalizes_refusal(settings):
    judge = _judge(settings)
    query = normalize_query("Explain quantum entanglement.")
    refusal = "I'm sorry, but I cannot explain quantum entanglement because I am not able to."
    answer = (
        "Quantum entanglement is a physical phenomenon where two particles share "
        "a single quantum state, so measuring one instantly determines the other's "
        "state regardless of distance."
    )
    assert judge.score(query, refusal, 500).factuality < judge.score(query, answer, 500).factuality


def test_completeness_rewards_multi_part_coverage(settings):
    judge = _judge(settings)
    query = normalize_query("Explain what Docker is and how it differs from a virtual machine?")
    partial = "Docker is a containerization platform for packaging applications."
    full = (
        "Docker is a containerization platform that packages applications and their "
        "dependencies into lightweight containers. A virtual machine virtualizes an "
        "entire operating system with a hypervisor, while Docker containers share "
        "the host kernel, which makes them start faster and use fewer resources."
    )
    assert judge.score(query, full, 500).completeness > judge.score(query, partial, 500).completeness


def test_readability_prefers_structured_text(settings):
    judge = _judge(settings)
    query = normalize_query("List the benefits of exercise.")
    blob = "exercise improves mood exercise helps weight exercise improves sleep exercise builds strength exercise reduces disease risk exercise boosts energy exercise improves memory exercise supports bone health exercise lowers stress exercise enhances lifespan"
    structured = (
        "Regular exercise provides several benefits:\n"
        "1. Improved cardiovascular health.\n"
        "2. Better mood and lower stress.\n"
        "3. Stronger muscles and bones.\n"
        "4. Improved sleep quality.\n"
    )
    assert judge.score(query, structured, 500).readability > judge.score(query, blob, 500).readability


def test_latency_monotonic(settings):
    judge = _judge(settings)
    query = normalize_query("Hello there, how are you doing today?")
    text = "I am doing well, thank you for asking! How can I help you today?"
    fast = judge.score(query, text, 100).latency
    slow = judge.score(query, text, 1100).latency
    assert fast > slow


def test_quality_gate(settings):
    judge = _judge(settings)
    query = normalize_query("What is 2 + 2?")
    good = judge.score(query, "Two plus two equals four.", 200)
    assert good.total > 0
    assert good.passed_gate == (good.total >= 0.55)


def test_split_sentences_handles_devanagari():
    parts = split_sentences("यो पहिलो वाक्य हो। यो दोस्रो वाक्य हो।")
    assert len(parts) == 2
