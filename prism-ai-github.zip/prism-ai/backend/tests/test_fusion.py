"""Fusion: dedupe, complement, citations, refusal-to-fuse cases."""
from app.judge.fusion import FusionEngine
from app.judge.scoring import Candidate, ScoreResult
from app.orchestrator.normalize import normalize_query


def _candidate(text: str, model: str, total: float = 0.8) -> Candidate:
    return Candidate(
        model_id=model, provider="fake", tier="primary", text=text, latency_ms=400,
        score=ScoreResult(total=total, passed_gate=True),
        sources=["https://example.com/source-a"] if model.endswith("a") else ["https://example.com/source-b"],
    )


def test_fuses_complementary_answers_without_duplicates():
    engine = FusionEngine()
    query = normalize_query("Tell me about the city of Paris.")
    a = _candidate(
        "Paris is the capital of France. It has about 2.1 million residents within city limits.",
        "fake/a",
    )
    b = _candidate(
        "Paris is the capital of France. It is famous for the Eiffel Tower and the Louvre.",
        "fake/b",
    )
    result = engine.fuse(query, a, b)
    assert result.used
    assert "Eiffel Tower" in result.text
    assert "Louvre" in result.text
    assert result.text.count("capital of France") == 1  # deduplicated
    assert len(result.sources) == 2  # citations preserved


def test_skips_fusion_when_winner_too_strong():
    engine = FusionEngine()
    query = normalize_query("What is photosynthesis?")
    a = _candidate("A great answer about photosynthesis.", "fake/a", total=0.95)
    b = _candidate("A weaker answer.", "fake/b", total=0.62)
    result = engine.fuse(query, a, b)
    assert not result.used
    assert result.text == a.text
    assert result.skipped_reason == "winner_too_strong"


def test_skips_fusion_below_quality_bar():
    engine = FusionEngine()
    query = normalize_query("What is a black hole?")
    a = _candidate("A mediocre answer.", "fake/a", total=0.58)
    b = _candidate("Another mediocre answer.", "fake/b", total=0.57)
    result = engine.fuse(query, a, b)
    assert not result.used
    assert result.skipped_reason == "below_fusion_quality_bar"


def test_skips_fusion_on_contradiction():
    engine = FusionEngine()
    query = normalize_query("When did World War II end?")
    a = _candidate("World War II ended in 1945 when Germany surrendered in May.", "fake/a")
    b = _candidate("World War II ended in 1939, which is wrong.", "fake/b")
    result = engine.fuse(query, a, b)
    assert not result.used
    assert result.skipped_reason == "contradictory_candidates"


def test_skips_fusion_when_runner_up_redundant():
    engine = FusionEngine()
    query = normalize_query("What is water made of?")
    a = _candidate("Water is made of two hydrogen atoms and one oxygen atom.", "fake/a")
    b = _candidate("Water consists of hydrogen and oxygen.", "fake/b")
    result = engine.fuse(query, a, b)
    # The runner-up adds no unique information -> not used.
    assert not result.used or "hydrogen" in result.text
