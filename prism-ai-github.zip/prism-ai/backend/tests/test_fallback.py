"""Fallback chain: cloud -> user keys -> local -> safe cache -> queue -> failure."""
import uuid

from app.embeddings.embedder import LocalHashEmbedder
from app.orchestrator.fallback import FallbackChain
from app.orchestrator.fanout import FanoutOrchestrator
from app.orchestrator.normalize import normalize_query
from app.providers.base import ErrorType
from app.providers.registry import ModelRegistry

from .conftest import add_models
from .fakes import FakeAdapter

Q = "What is the capital of France?"


async def _setup(db, settings, cloud_error=ErrorType.PROVIDER_DOWN, cloud_latency=0.01):
    registry = ModelRegistry(db, settings)
    embedder = LocalHashEmbedder(settings.embedding_dim)
    orchestrator = FanoutOrchestrator(registry, embedder, settings)
    cloud = FakeAdapter(answers={}, error=cloud_error, latency=cloud_latency)
    local = FakeAdapter(
        answers={"llama": "The capital of France is Paris, served by a local model."},
        latency=0.01,
    )
    registry._adapters["cloud"] = cloud
    registry._adapters["local"] = local
    await add_models(db, [
        {"id": "cloud/a", "provider": "cloud", "tier": "primary", "status": "ACTIVE"},
        {"id": "local/llama", "provider": "local", "tier": "local", "status": "ACTIVE"},
    ])
    return orchestrator, registry


async def test_falls_back_to_local_when_cloud_fails(db, settings):
    orchestrator, _ = await _setup(db, settings)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    assert outcome.status == "completed"
    assert "local model" in outcome.answer
    # The local answer came from the fallback tier.
    assert outcome.candidates[0].candidate.tier == "local"


async def test_clean_failure_when_everything_fails(db, settings):
    orchestrator, _ = await _setup(db, settings)
    orchestrator.registry._adapters["local"] = FakeAdapter(
        answers={}, error=ErrorType.PROVIDER_DOWN, latency=0.01
    )
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    assert outcome.status == "failed"
    assert outcome.answer is None
    assert outcome.error == "no_model_available"
    assert "no safe cached answer" in (outcome.error_detail or "")


async def test_fallback_to_safe_cache_as_last_resort(db, settings):
    orchestrator, _ = await _setup(db, settings)
    # Both tiers fail.
    orchestrator.registry._adapters["local"] = FakeAdapter(
        answers={}, error=ErrorType.QUOTA_EXHAUSTED, latency=0.01
    )
    normalized = normalize_query(Q)
    embedding = orchestrator.cache.embed_sync([Q])[0]
    await orchestrator.cache.store(
        normalized, answer="Cached: The capital of France is Paris.",
        embedding=embedding, confidence=0.96, user_id=None,
    )
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    # First lookup (normal threshold) also hits — cache-first is by design, and
    # with an exact safe match that is the correct behaviour.
    assert outcome.status == "from_cache"
    assert "Cached" in outcome.answer


async def test_fallback_chain_cache_stage_directly(db, settings):
    """Exercise stage 4 in isolation via FallbackChain.resolve."""
    orchestrator, _ = await _setup(db, settings)
    orchestrator.registry._adapters["local"] = FakeAdapter(
        answers={}, error=ErrorType.RATE_LIMITED, latency=0.01
    )
    normalized = normalize_query(Q)
    embedding = orchestrator.cache.embed_sync([Q])[0]
    await orchestrator.cache.store(
        normalized, answer="Cached fallback answer about Paris.",
        embedding=embedding, confidence=0.97, user_id=None,
    )
    chain = FallbackChain(orchestrator, settings)
    outcome = await chain.resolve(
        user_id=None, conversation_id=None, normalized=normalized,
        query_embedding=embedding, messages=[], tried={"cloud/a"},
        request_id=uuid.uuid4(), started=0.0, prior_failures=[],
    )
    assert outcome.status == "from_cache"
    assert "Cached fallback" in outcome.answer
    assert outcome.metadata.get("fallback_cache") is True


async def test_queue_stage_when_enabled(db, settings, monkeypatch):
    orchestrator, _ = await _setup(db, settings)
    orchestrator.registry._adapters["local"] = FakeAdapter(
        answers={}, error=ErrorType.PROVIDER_DOWN, latency=0.01
    )
    settings.queue_enabled = True
    from app.queue import tasks

    monkeypatch.setattr(tasks, "enqueue_processing", lambda rid: None)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    assert outcome.status == "queued"
    assert outcome.queue_position is not None
    settings.queue_enabled = False


async def test_first_round_models_are_not_retried_in_fallback(db, settings):
    orchestrator, _ = await _setup(db, settings)
    cloud = orchestrator.registry._adapters["cloud"]
    calls_before = len(cloud.calls)
    outcome = await orchestrator.answer(user_id=None, conversation_id=None, query_text=Q)
    # Cloud failed once in round 1 and must not be called again in fallback.
    assert len(cloud.calls) == calls_before + 1
    assert outcome.status == "completed"
