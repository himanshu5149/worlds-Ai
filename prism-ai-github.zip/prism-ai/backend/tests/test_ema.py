"""Feedback EMA: gradual weight updates, no overreaction, clamps."""
import pytest

from app.feedback.ema import EmaWeightUpdater, FeedbackService

from .conftest import add_models


def test_first_feedback_is_fully_dampened():
    updater = EmaWeightUpdater()
    new, alpha = updater.next_weight(rating=1, current=1.0, samples=0)
    assert alpha == 0.0
    assert new == 1.0


def test_ema_moves_gradually_with_enough_samples():
    updater = EmaWeightUpdater()
    _, alpha10 = updater.next_weight(rating=1, current=1.0, samples=10)
    assert alpha10 == pytest.approx(0.10)
    new, _ = updater.next_weight(rating=1, current=1.0, samples=10)
    assert new == pytest.approx(1.0 * 0.9 + 1.15 * 0.1)
    down, _ = updater.next_weight(rating=-1, current=1.0, samples=10)
    assert down == pytest.approx(1.0 * 0.9 + 0.85 * 0.1)
    assert down < 1.0 < new


def test_weight_stays_within_bounds():
    updater = EmaWeightUpdater()
    for current in (0.01, 0.05, 0.1, 0.5, 1.0, 1.5, 2.0, 2.4, 2.49):
        for rating in (1, -1):
            new, _ = updater.next_weight(rating=rating, current=current, samples=100)
            assert 0.10 <= new <= 2.50
            # Bounded movement: EMA steps are always small.
            assert abs(new - current) <= 0.2


async def test_service_updates_selected_model(db, settings):
    import uuid

    from sqlalchemy import select

    from app.db.models import Feedback, Model, ModelInvocation, ModelResponse, Request

    await add_models(db, [{"id": "fake/winner", "provider": "fake", "weight": 1.0, "status": "ACTIVE"}])
    rid = uuid.uuid4()
    uid = uuid.uuid4()
    async with db() as session:
        session.add(Request(id=rid, normalized_query="q?", query_hash="h", status="completed"))
        await session.flush()
        inv = ModelInvocation(request_id=rid, model_id="fake/winner", status="success")
        session.add(inv)
        await session.flush()
        session.add(ModelResponse(invocation_id=inv.id, request_id=rid, model_id="fake/winner",
                                 raw_answer="answer", score=0.8, selected=True))
        await session.commit()

    service = FeedbackService(db, settings=settings)
    updates = await service.record_and_update(request_id=rid, user_id=uid, rating=1)
    assert len(updates) == 1
    assert updates[0].model_id == "fake/winner"

    async with db() as session:
        feedback = (await session.scalars(select(Feedback))).all()
        assert len(feedback) == 1 and feedback[0].rating == 1
        model = await session.get(Model, "fake/winner")
        # samples=0 -> fully dampened; weight unchanged on the very first event.
        assert model.routing_weight == pytest.approx(1.0)
        assert model.meta["feedback_samples"] == 1
