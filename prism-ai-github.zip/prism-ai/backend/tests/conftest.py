"""Shared fixtures: SQLite-backed settings, DB, app client, fake providers."""
from __future__ import annotations

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.core.config import Settings
from app.db.base import Base
from app.db.session import configure_db
from app.providers.base import (
    ChatMessage,
    ErrorType,
)

from .fakes import FakeAdapter


@pytest.fixture(scope="session")
def settings(tmp_path_factory) -> Settings:
    db_path = tmp_path_factory.mktemp("prism") / "test.db"
    return Settings(
        env="test",
        database_url=f"sqlite+aiosqlite:///{db_path}",
        redis_url="redis://localhost:6399/0",
        jwt_secret="test-secret",
        enable_background_tasks=False,
        allow_mock_providers=False,
        queue_enabled=False,
        soft_timeout_s=0.4,
        hard_timeout_s=1.2,
        fallback_timeout_s=0.8,
        health_check_interval_s=30.0,
        health_degrade_after_failures=2,
        health_down_after_failures=5,
        health_recover_after_successes=2,
        health_backoff_base_s=1.0,
        health_backoff_max_s=60.0,
        cache_similarity_threshold=0.92,
        cache_confidence_threshold=0.85,
        cache_fallback_similarity=0.95,
        cache_entity_jaccard_min=0.6,
        cache_time_sensitive_max_age_s=900,
        judge_quality_gate=0.55,
        judge_fusion_min_score=0.60,
        judge_fusion_score_margin=0.08,
        embedding_backend="local-hash",
        embedding_dim=1536,
        auth_rate_limit_per_minute=1000,
        rate_limit_chat_per_minute=1000,
        cors_origins=[],
        log_level="WARNING",
        storage_dir=str(tmp_path_factory.mktemp("uploads")),
        max_upload_mb=1,
    )


@pytest.fixture(scope="session", autouse=True)
def _global_db(settings):
    """Point the app's global session factory at the shared test database."""
    configure_db(settings)


@pytest_asyncio.fixture()
async def db(settings):
    engine = create_async_engine(settings.database_url)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    yield factory
    await engine.dispose()


@pytest.fixture()
def client(settings, db):
    from fastapi.testclient import TestClient

    from app.main import create_app

    with TestClient(create_app(settings)) as test_client:
        yield test_client


def make_fake_adapter(
    *,
    answers: dict[str, str] | None = None,
    latency: float = 0.02,
    error: ErrorType | None = None,
    health_ok: bool = True,
    key: str | None = None,
) -> FakeAdapter:
    return FakeAdapter(
        answers=answers or {},
        latency=latency,
        error=error,
        health_ok=health_ok,
        api_key=key,
    )


async def add_models(factory, specs: list[dict]) -> None:
    from app.db.models import Model

    async with factory() as session:
        existing = set((await session.scalars(select(Model.id))).all())
        for spec in specs:
            if spec["id"] in existing:
                continue
            session.add(
                Model(
                    id=spec["id"],
                    provider=spec["provider"],
                    tier=spec.get("tier", "primary"),
                    routing_weight=spec.get("weight", 1.0),
                    status=spec.get("status", "ACTIVE"),
                    credentials_required=spec.get("credentials_required", False),
                    context_window=128_000,
                )
            )
        await session.commit()


from sqlalchemy import select


def register_user(client, email: str = "user@example.com", password: str = "password123"):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password},
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["access_token"]


def auth_header(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def user_question(messages: list[ChatMessage]) -> str:
    for m in reversed(messages):
        if m.role == "user":
            return m.content
    return ""
