"""Health manager state machine: DEGRADED, DOWN, COOLING, AUTH_REQUIRED, recovery."""
import pytest

from app.health.manager import HealthManager
from app.providers.base import ErrorType, HealthResult, ModelStatus
from app.providers.registry import ModelRegistry

from .conftest import add_models, make_fake_adapter
from .fakes import FakeAdapter

MODEL = "fake/m-1"


def _stub(ok: bool, error_type: ErrorType | None = None):
    return HealthResult(
        ok=ok,
        status=ModelStatus.ACTIVE if ok else ModelStatus.DOWN,
        error_type=error_type,
        latency_ms=5.0,
        message="scripted",
    )


@pytest.fixture()
async def registry(db, settings):
    registry = ModelRegistry(db, settings)
    await add_models(db, [{"id": MODEL, "provider": "fake", "status": "UNKNOWN"}])
    return registry


async def _install(registry, adapter) -> HealthManager:
    registry._adapters["fake"] = adapter
    return HealthManager(registry, registry.settings)


async def _status(registry, model_id):
    model = await registry.get_model(model_id)
    return ModelStatus(model.status)


async def test_success_sets_active(registry):
    manager = await _install(registry, make_fake_adapter(health_ok=True))
    await manager.run_once(now=1000.0)
    assert await _status(registry, MODEL) == ModelStatus.ACTIVE


async def test_two_failures_degrades(registry):
    adapter = make_fake_adapter(health_ok=False)
    manager = await _install(registry, adapter)
    await manager.run_once(now=1000.0)
    assert await _status(registry, MODEL) == ModelStatus.UNKNOWN  # 1st failure: no promotion
    await manager.run_once(now=2000.0)
    assert await _status(registry, MODEL) == ModelStatus.DEGRADED


async def test_five_failures_down(registry):
    manager = await _install(registry, make_fake_adapter(health_ok=False))
    for i in range(5):
        await manager.run_once(now=1000.0 + i * 500.0)
    assert await _status(registry, MODEL) == ModelStatus.DOWN


async def test_recovery_requires_consecutive_successes(registry):
    manager = await _install(registry, make_fake_adapter(health_ok=False))
    for i in range(5):
        await manager.run_once(now=1000.0 + i * 500.0)
    assert await _status(registry, MODEL) == ModelStatus.DOWN

    manager.registry._adapters["fake"] = make_fake_adapter(health_ok=True)
    await manager.run_once(now=5000.0)
    assert await _status(registry, MODEL) == ModelStatus.DOWN  # one success is not enough
    await manager.run_once(now=6000.0)
    assert await _status(registry, MODEL) == ModelStatus.DEGRADED  # two-stage recovery
    await manager.run_once(now=7000.0)
    assert await _status(registry, MODEL) == ModelStatus.ACTIVE


async def test_backoff_skips_early_checks(registry):
    manager = await _install(registry, make_fake_adapter(health_ok=False))
    await manager.run_once(now=1000.0)  # 1 failure -> backoff scheduled
    records = await manager.run_once(now=1000.1)  # 0.1s later: inside backoff window
    assert records == []  # nothing probed


async def test_rate_limit_cools(registry):
    adapter = FakeAdapter(health_results=[_stub(False, ErrorType.RATE_LIMITED)])
    manager = await _install(registry, adapter)
    await manager.run_once(now=1000.0)
    assert await _status(registry, MODEL) == ModelStatus.COOLING


async def test_auth_failure_sets_auth_required(registry):
    adapter = FakeAdapter(health_results=[_stub(False, ErrorType.AUTH_EXPIRED)])
    manager = await _install(registry, adapter)
    await manager.run_once(now=1000.0)
    assert await _status(registry, MODEL) == ModelStatus.AUTH_REQUIRED


async def test_passive_rate_limit_signal(registry):
    manager = await _install(registry, make_fake_adapter(health_ok=True))
    await manager.on_invocation_result(MODEL, ok=False, error_type=ErrorType.RATE_LIMITED)
    assert await _status(registry, MODEL) == ModelStatus.COOLING


async def test_quota_signal_sets_paid_required(registry):
    manager = await _install(registry, make_fake_adapter(health_ok=True))
    await manager.on_invocation_result(MODEL, ok=False, error_type=ErrorType.QUOTA_EXHAUSTED)
    assert await _status(registry, MODEL) == ModelStatus.PAID_REQUIRED


async def test_events_recorded(registry):
    manager = await _install(registry, make_fake_adapter(health_ok=False))
    await manager.run_once(now=1000.0)
    from sqlalchemy import func, select

    from app.db.models import HealthEvent

    async with registry.session_factory() as session:
        count = await session.scalar(select(func.count()).select_from(HealthEvent))
    assert count == 1
