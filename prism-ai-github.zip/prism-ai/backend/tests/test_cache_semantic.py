"""Semantic cache service: store/lookup, guardrail-gated hits, purges."""
import uuid
from datetime import UTC

import pytest

from app.cache.semantic import SemanticCacheService
from app.embeddings.embedder import LocalHashEmbedder
from app.orchestrator.normalize import normalize_query


@pytest.fixture()
def cache(db, settings):
    return SemanticCacheService(db, LocalHashEmbedder(settings.embedding_dim), settings)


async def test_store_and_hit(cache):
    query = normalize_query("What is the capital of France?")
    embedding = cache.embed_sync([query.text])[0]
    await cache.store(
        query, answer="The capital of France is Paris.", embedding=embedding,
        confidence=0.95, user_id=None,
    )
    hit = await cache.lookup(query, embedding=embedding, user_id=None)
    assert hit is not None
    assert "Paris" in hit.answer
    assert hit.confidence == 0.95


async def test_miss_on_different_language(cache):
    query = normalize_query("What is the capital of France?")
    other = normalize_query("Quelle est la capitale de la France ?")
    embedding = cache.embed_sync([query.text])[0]
    await cache.store(
        query, answer="The capital of France is Paris.", embedding=embedding,
        confidence=0.95, user_id=None,
    )
    hit = await cache.lookup(other, embedding=cache.embed_sync([other.text])[0], user_id=None)
    assert hit is None


async def test_miss_on_different_intent(cache):
    query = normalize_query("What is the capital of France?")
    other = normalize_query("How do I travel to Paris on a budget?")  # howto
    embedding = cache.embed_sync([query.text])[0]
    await cache.store(
        query, answer="The capital of France is Paris.", embedding=embedding,
        confidence=0.95, user_id=None,
    )
    hit = await cache.lookup(other, embedding=cache.embed_sync([other.text])[0], user_id=None)
    assert hit is None


async def test_miss_on_key_entity_mismatch(cache):
    q1 = normalize_query("What was the population of France in 2020?")
    q2 = normalize_query("What was the population of France in 2023?")
    embedding = cache.embed_sync([q1.text])[0]
    await cache.store(
        q1, answer="About 67 million in 2020.", embedding=embedding,
        confidence=0.95, user_id=None,
    )
    hit = await cache.lookup(q2, embedding=cache.embed_sync([q2.text])[0], user_id=None)
    assert hit is None  # dates differ -> must regenerate


async def test_time_sensitive_entries_go_stale(cache, settings):
    query = normalize_query("What is the weather today in Kathmandu?")
    assert query.time_sensitive
    embedding = cache.embed_sync([query.text])[0]
    await cache.store(
        query, answer="Sunny, 24C.", embedding=embedding, confidence=0.95, user_id=None,
    )
    # Backdate the entry beyond the freshness window.
    from datetime import datetime, timedelta

    from sqlalchemy import select

    from app.db.models import CacheEntry

    async with cache.session_factory() as session:
        entry = (await session.scalars(select(CacheEntry))).first()
        entry.created_at = datetime.now(UTC) - timedelta(
            seconds=settings.cache_time_sensitive_max_age_s + 60
        )
        await session.commit()
    hit = await cache.lookup(query, embedding=embedding, user_id=None)
    assert hit is None


async def test_low_confidence_entries_not_served(cache):
    query = normalize_query("Tell me about black holes.")
    embedding = cache.embed_sync([query.text])[0]
    await cache.store(
        query, answer="Black holes are dense objects.", embedding=embedding,
        confidence=0.5, user_id=None,
    )
    hit = await cache.lookup(query, embedding=embedding, user_id=None)
    assert hit is None


async def test_expiry(cache, settings):
    query = normalize_query("Who wrote Hamlet?")
    embedding = cache.embed_sync([query.text])[0]
    await cache.store(
        query, answer="William Shakespeare.", embedding=embedding,
        confidence=0.95, user_id=None,
    )
    from datetime import datetime, timedelta

    from sqlalchemy import select

    from app.db.models import CacheEntry

    async with cache.session_factory() as session:
        entry = (await session.scalars(select(CacheEntry))).first()
        entry.expires_at = datetime.now(UTC) - timedelta(minutes=1)
        await session.commit()
    hit = await cache.lookup(query, embedding=embedding, user_id=None)
    assert hit is None


async def test_fallback_mode_uses_stricter_similarity(cache):
    import math

    query = normalize_query("What is the capital of Nepal?")
    embedding = cache.embed_sync([query.text])[0]
    await cache.store(
        query, answer="Kathmandu.", embedding=embedding, confidence=0.95, user_id=None,
    )
    # Perturb the stored embedding to a cosine of ~0.9487: inside the normal
    # threshold (0.92) but below the stricter fallback threshold (0.95).
    from sqlalchemy import select

    from app.db.models import CacheEntry

    dim = len(embedding)
    orthogonal = [1.0 if i < dim // 2 else -1.0 for i in range(dim)]
    norm = math.sqrt(sum(v * v for v in orthogonal))
    orthogonal = [v / norm for v in orthogonal]
    perturbed = [0.9 * v + 0.3 * w for v, w in zip(embedding, orthogonal)]
    expected_cos = 0.9 / math.sqrt(0.9**2 + 0.3**2)

    async with cache.session_factory() as session:
        entry = (await session.scalars(select(CacheEntry))).first()
        entry.embedding = perturbed
        await session.commit()

    hit_fallback = await cache.lookup(query, embedding=embedding, user_id=None, is_fallback=True)
    assert hit_fallback is None
    hit_normal = await cache.lookup(query, embedding=embedding, user_id=None)
    assert hit_normal is not None
    assert abs(hit_normal.similarity - expected_cos) < 0.02


async def test_user_isolation_and_purge(cache):
    query = normalize_query("What is the capital of France?")
    embedding = cache.embed_sync([query.text])[0]
    user_a, user_b = uuid.uuid4(), uuid.uuid4()
    await cache.store(
        query, answer="Paris.", embedding=embedding, confidence=0.95, user_id=user_a,
    )
    hit_b = await cache.lookup(query, embedding=embedding, user_id=user_b)
    assert hit_b is None  # not global, not user_b's
    hit_a = await cache.lookup(query, embedding=embedding, user_id=user_a)
    assert hit_a is not None
    assert await cache.purge_user(user_a) == 1
    hit_again = await cache.lookup(query, embedding=embedding, user_id=user_a)
    assert hit_again is None
