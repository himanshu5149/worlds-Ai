"""Deterministic in-memory provider used across the test suite."""
from __future__ import annotations

import asyncio

import httpx

from app.providers.base import (
    ChatMessage,
    ErrorType,
    HealthResult,
    ModelStatus,
    ProviderAdapter,
    ProviderError,
    ProviderResponse,
    RateLimitInfo,
    StreamChunk,
)


class FakeAdapter(ProviderAdapter):
    name = "fake"
    credentials_required = False
    supports_streaming = True

    def __init__(
        self,
        *,
        answers: dict[str, str] | None = None,
        latency: float = 0.02,
        error: ErrorType | None = None,
        health_ok: bool = True,
        health_results: list | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.answers = answers or {}
        self.latency = latency
        self.error = error
        self.health_ok = health_ok
        self.health_results = health_results
        self._health_index = 0
        self.calls: list[str] = []

    def _text_for(self, model: str, messages: list[ChatMessage]) -> str:
        if model in self.answers:
            return self.answers[model]
        question = ""
        for m in reversed(messages):
            if m.role == "user":
                question = m.content
                break
        return f"Here is a helpful, detailed and accurate answer to your question about {question[:60]}."

    async def generate(self, *, model, messages, temperature=0.4, max_tokens=1024, timeout=None):
        await asyncio.sleep(self.latency)
        self.calls.append(model)
        if self.error is not None:
            raise ProviderError(self.error, "simulated failure", provider=self.name)
        return ProviderResponse(
            text=self._text_for(model, messages),
            model=model,
            provider=self.name,
            latency_ms=self.latency * 1000,
            tokens_in=10,
            tokens_out=40,
            finish_reason="stop",
        )

    async def stream_generate(self, *, model, messages, temperature=0.4, max_tokens=1024, timeout=None):
        async for _ in []:  # pragma: no cover
            yield StreamChunk(text="")
        for word in self._text_for(model, messages).split(" "):
            yield StreamChunk(text=word + " ")
        yield StreamChunk(text="", finish_reason="stop")

    async def check_health(self) -> HealthResult:
        if self.health_results is not None:
            index = min(self._health_index, len(self.health_results) - 1)
            self._health_index += 1
            return self.health_results[index]
        if self.health_ok:
            return HealthResult(ok=True, status=ModelStatus.ACTIVE, latency_ms=5.0)
        return HealthResult(
            ok=False, status=ModelStatus.DOWN, error_type=ErrorType.PROVIDER_DOWN,
            latency_ms=5.0, message="simulated down",
        )

    def parse_rate_limit_headers(self, headers: httpx.Headers) -> RateLimitInfo:
        return RateLimitInfo()
