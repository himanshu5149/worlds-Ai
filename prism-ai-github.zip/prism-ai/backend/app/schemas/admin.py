from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class ModelOut(BaseModel):
    id: str
    provider: str
    tier: str
    routing_weight: float
    context_window: int | None
    status: str
    capabilities: dict[str, Any] = Field(default_factory=dict)
    requires_verification: bool = False
    credentials_required: bool = True
    last_health_check_at: Any = None


class ModelPatch(BaseModel):
    status: Literal[
        "ACTIVE", "DEGRADED", "COOLING", "DOWN", "AUTH_REQUIRED", "PAID_REQUIRED"
    ] | None = None
    routing_weight: float | None = Field(default=None, ge=0.0, le=10.0)


class CredentialIn(BaseModel):
    provider: str
    api_key: str = Field(min_length=8, max_length=512)
    note: str | None = Field(default=None, max_length=255)


class HealthCheckResult(BaseModel):
    model_id: str
    status: str
    error_type: str | None = None
    latency_ms: float = 0.0
    quota_remaining: int | None = None
    message: str = ""


class ModelHealthCard(BaseModel):
    model_id: str
    provider: str
    status: str
    success_rate_24h: float | None = None
    latency_p95_ms: float | None = None
    invocations_24h: int = 0
    quota_remaining: int | None = None


class MetricsOut(BaseModel):
    window_hours: int = 24
    total_requests: int = 0
    success_rate: float | None = None
    cache_hit_rate: float | None = None
    latency_p95_ms: float | None = None
    fused_answers: int = 0
    models: list[ModelHealthCard] = Field(default_factory=list)


class Alert(BaseModel):
    severity: Literal["critical", "warning", "info"]
    model_id: str | None = None
    message: str


class AlertsOut(BaseModel):
    alerts: list[Alert]


class HealthEventOut(BaseModel):
    model_id: str
    status: str
    error_type: str | None = None
    latency_ms: float | None = None
    quota_remaining: int | None = None
    message: str | None = None
    created_at: Any


class DeleteResult(BaseModel):
    deleted: dict[str, int] = Field(default_factory=dict)
    files_removed: int = 0
    account_deleted: bool = False
