from __future__ import annotations

import uuid
from typing import Any, Literal

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=16_000)
    conversation_id: uuid.UUID | None = None
    attachments: list[uuid.UUID] = Field(default_factory=list, max_length=5)
    preferences: dict[str, Any] = Field(default_factory=dict)
    stream: bool = False


class ChatResponse(BaseModel):
    request_id: uuid.UUID
    answer: str | None = None
    status: Literal["completed", "from_cache", "queued", "failed"]
    from_cache: bool = False
    fused: bool = False
    latency_ms: float = 0.0
    message: str | None = None
    error: str | None = None
    queue_position: int | None = None
    # deliberately absent: model/provider names


class CandidateOut(BaseModel):
    label: str  # "Candidate A"
    text: str
    score_pct: int  # relative quality, 0-100
    is_winner: bool
    fused: bool
    # provider/model fields populated ONLY when revealed=true (admin, audited)
    model_id: str | None = None
    provider: str | None = None


class CandidatesResponse(BaseModel):
    request_id: uuid.UUID
    revealed: bool
    candidates: list[CandidateOut]


class FeedbackRequest(BaseModel):
    rating: Literal[1, -1]
    comment: str | None = Field(default=None, max_length=2000)


class FeedbackResponse(BaseModel):
    accepted: bool
    weight_updates: list[dict[str, Any]] = Field(default_factory=list)


class MessageOut(BaseModel):
    id: uuid.UUID
    role: str
    content: str
    created_at: Any


class ConversationOut(BaseModel):
    id: uuid.UUID
    title: str | None = None
    created_at: Any
    updated_at: Any


class ConversationDetail(BaseModel):
    conversation: ConversationOut
    messages: list[MessageOut]
    requests: list[dict[str, Any]] = Field(default_factory=list)


class RequestStatus(BaseModel):
    request_id: uuid.UUID
    status: str
    answer: str | None = None
    error: str | None = None
