from __future__ import annotations

import uuid
from typing import Any

from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    display_name: str | None = Field(default=None, max_length=120)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    expires_in_minutes: int


class UserOut(BaseModel):
    id: uuid.UUID
    email: EmailStr
    role: str
    display_name: str | None = None
    preferences: dict[str, Any] = Field(default_factory=dict)
